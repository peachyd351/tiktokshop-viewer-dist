// Tự cập nhật bản cài "Load unpacked": Chrome không cập nhật được, extension cũng không tự ghi
// được thư mục của mình. File System Access API thì được: người dùng chọn thư mục 1 lần (lưu
// handle trong IndexedDB), sau đó mỗi lần cập nhật = tải zip từ repo phát hành → kiểm SHA-256 →
// giải nén → ghi đè (manifest.json ghi cuối) → chrome.runtime.reload().

import { send } from "./common.js";

const $ = (id) => document.getElementById(id);
const manifest = chrome.runtime.getManifest();
let update = null;
let busy = false;

// ---------- Lưu handle thư mục ----------

function db() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open("tts-updater", 1);
    req.onupgradeneeded = () => req.result.createObjectStore("kv");
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function kv(key, value) {
  const store = (await db()).transaction("kv", value === undefined ? "readonly" : "readwrite").objectStore("kv");
  return new Promise((resolve) => {
    const req = value === undefined ? store.get(key) : store.put(value, key);
    req.onsuccess = () => resolve(value === undefined ? req.result : undefined);
    req.onerror = () => resolve(null);
  });
}

function setStatus(text, cls = "") {
  $("status").textContent = text;
  $("status").className = cls || "muted";
}

function progress(p) {
  const bar = document.querySelector(".bar");
  bar.hidden = false;
  bar.firstElementChild.style.width = `${Math.round(p * 100)}%`;
}

// ---------- Giải nén (stored / deflate) ----------

async function inflateRaw(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function unzip(buf) {
  const dv = new DataView(buf);
  const u8 = new Uint8Array(buf);
  let end = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new Error("File zip hỏng");
  const count = dv.getUint16(end + 10, true);
  let p = dv.getUint32(end + 16, true);
  const dec = new TextDecoder();
  const files = [];
  for (let n = 0; n < count; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error("File zip hỏng (mục lục)");
    const method = dv.getUint16(p + 10, true);
    const size = dv.getUint32(p + 20, true);
    const nameLen = dv.getUint16(p + 28, true);
    const skip = nameLen + dv.getUint16(p + 30, true) + dv.getUint16(p + 32, true);
    const local = dv.getUint32(p + 42, true);
    const name = dec.decode(u8.subarray(p + 46, p + 46 + nameLen)).replace(/\\/g, "/");
    p += 46 + skip;
    if (name.endsWith("/")) continue;
    if (name.split("/").includes("..")) throw new Error(`Đường dẫn lạ trong gói: ${name}`);
    const start = local + 30 + dv.getUint16(local + 26, true) + dv.getUint16(local + 28, true);
    const raw = u8.subarray(start, start + size);
    if (method === 0) files.push({ name, data: raw.slice() });
    else if (method === 8) files.push({ name, data: await inflateRaw(raw) });
    else throw new Error(`Kiểu nén không hỗ trợ: ${method}`);
  }
  return files;
}

async function sha256(buf) {
  const hash = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ---------- Thư mục extension ----------

async function readManifest(dir) {
  try {
    return JSON.parse(await (await (await dir.getFileHandle("manifest.json")).getFile()).text());
  } catch {
    return null;
  }
}

const isOurs = (m) => m?.name === manifest.name;

async function allowed(dir) {
  if ((await dir.queryPermission({ mode: "readwrite" })) === "granted") return true;
  return (await dir.requestPermission({ mode: "readwrite" })) === "granted";
}

async function pickDir() {
  const dir = await window.showDirectoryPicker({ id: "tts-viewer", mode: "readwrite" });
  if (!isOurs(await readManifest(dir))) throw new Error("Thư mục này không phải thư mục TTS Viewer đang cài (không thấy manifest.json của extension). Hãy chọn lại.");
  await kv("dir", dir);
  return dir;
}

async function writeFile(root, path, data) {
  const parts = path.split("/").filter(Boolean);
  let dir = root;
  for (const part of parts.slice(0, -1)) dir = await dir.getDirectoryHandle(part, { create: true });
  const writable = await (await dir.getFileHandle(parts.at(-1), { create: true })).createWritable();
  await writable.write(data);
  await writable.close();
}

async function run(forcePick) {
  if (busy || !update) return;
  busy = true;
  $("go").disabled = true;
  try {
    let dir = forcePick ? null : await kv("dir");
    if (dir && (!(await allowed(dir)) || !isOurs(await readManifest(dir)))) dir = null;
    if (!dir) {
      setStatus("Chọn thư mục extension đang cài…");
      dir = await pickDir();
      if (!(await allowed(dir))) throw new Error("Bạn chưa cho phép ghi vào thư mục.");
    }
    $("dir").textContent = `Thư mục: ${dir.name}`;

    setStatus(`Đang tải bản ${update.version}…`);
    progress(0.05);
    const res = await fetch(update.url, { cache: "no-store" });
    if (!res.ok) throw new Error(`Không tải được bản cập nhật (HTTP ${res.status})`);
    const buf = await res.arrayBuffer();
    if (update.sha256 && (await sha256(buf)) !== update.sha256) throw new Error("File tải về bị lỗi (sai mã kiểm tra), thử lại sau");
    progress(0.25);

    const files = await unzip(buf);
    const mf = files.find((f) => f.name === "manifest.json");
    if (!mf || !isOurs(JSON.parse(new TextDecoder().decode(mf.data)))) throw new Error("Gói cập nhật không phải TTS Viewer");
    // manifest.json ghi cuối: dừng giữa chừng thì Chrome vẫn nạp như bản cũ.
    const ordered = [...files.filter((f) => f !== mf), mf];
    for (let i = 0; i < ordered.length; i++) {
      setStatus(`Đang ghi file ${i + 1}/${ordered.length}: ${ordered[i].name}`);
      await writeFile(dir, ordered[i].name, ordered[i].data);
      progress(0.3 + (0.7 * (i + 1)) / ordered.length);
    }
    setStatus(`✓ Đã cập nhật lên ${update.version}. Đang khởi động lại extension…`, "ok");
    $("go").textContent = "Xong";
    setTimeout(() => chrome.runtime.reload(), 1200);
  } catch (err) {
    setStatus(err?.name === "AbortError" ? "Đã huỷ chọn thư mục." : String(err?.message || err), err?.name === "AbortError" ? "" : "error");
    $("go").disabled = false;
    $("go").textContent = "Thử lại";
  } finally {
    busy = false;
  }
}

$("cur").textContent = `Bản đang dùng: ${manifest.version}`;
$("go").addEventListener("click", () => run(false));
$("pick").addEventListener("click", () => run(true));
kv("dir")
  .then((dir) => dir && ($("dir").textContent = `Thư mục đã chọn: ${dir.name}`))
  .catch(() => {});

send({ type: "checkUpdate", force: true }).then((res) => {
  update = res.ok ? res.update : null;
  if (!res.ok) return setStatus(`Không kiểm tra được bản mới: ${res.error}`, "error");
  if (!update) {
    $("go").textContent = "Đang dùng bản mới nhất";
    return setStatus("Chưa có bản mới. Khi có, biểu tượng extension hiện chữ MỚI.");
  }
  $("next").textContent = `→ ${update.version}`;
  if (update.notes) {
    $("notes").hidden = false;
    $("notes").textContent = update.notes;
  }
  $("go").disabled = false;
  $("go").textContent = "Cập nhật ngay";
});
